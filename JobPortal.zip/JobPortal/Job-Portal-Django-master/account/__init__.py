from django.utils.translation import ugettext_lazy
